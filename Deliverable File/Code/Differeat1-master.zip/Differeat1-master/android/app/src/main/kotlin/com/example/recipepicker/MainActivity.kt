package com.example.recipepicker

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
